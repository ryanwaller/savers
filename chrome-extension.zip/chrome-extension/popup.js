const DEFAULT_APP_URL = "https://savers-production.up.railway.app";

const els = {
  bookmarkTitle: document.getElementById("bookmark-title"),
  bookmarkTags: document.getElementById("bookmark-tags"),
  suggestTags: document.getElementById("suggest-tags"),
  tagProposals: document.getElementById("tag-proposals"),
  bookmarkDescription: document.getElementById("bookmark-description"),
  collectionSelect: document.getElementById("collection-select"),
  collectionTrigger: document.getElementById("collection-trigger"),
  collectionTriggerLabel: document.getElementById("collection-trigger-label"),
  collectionPicker: document.getElementById("collection-picker"),
  collectionSearch: document.getElementById("collection-search"),
  collectionOptions: document.getElementById("collection-options"),
  aiSuggestion: document.getElementById("ai-suggestion"),
  aiSuggestionCopy: document.getElementById("ai-suggestion-copy"),
  suggestCollection: document.getElementById("suggest-collection"),
  applyAiSuggestion: document.getElementById("apply-ai-suggestion"),
  dismissAiSuggestion: document.getElementById("dismiss-ai-suggestion"),
  showCreate: document.getElementById("show-create"),
  refreshMeta: document.getElementById("refresh-meta"),
  createWrap: document.getElementById("create-wrap"),
  newCollectionName: document.getElementById("new-collection-name"),
  createCollection: document.getElementById("create-collection"),
  cancelCreate: document.getElementById("cancel-create"),
  openApp: document.getElementById("open-app"),
  saveBookmark: document.getElementById("save-bookmark"),
  status: document.getElementById("status"),
  aiStatus: document.getElementById("ai-status"),
  duplicateWarning: document.getElementById("duplicate-warning"),
  duplicateTitle: document.getElementById("duplicate-title"),
  openDuplicate: document.getElementById("open-duplicate"),
  saveAnyway: document.getElementById("save-anyway"),
  unsyncedBadge: document.getElementById("unsynced-badge"),
  unsyncedCount: document.getElementById("unsynced-count"),
};

let tagProposals = [];
let tagSuggestStatus = null;
let collectionOptionRows = [];

const state = {
  appUrl: DEFAULT_APP_URL,
  tabUrl: "",
  tabTitle: "",
  metadata: null,
  flatCollections: [],
  aiSuggestion: null,
  collectionTouched: false,
  duplicate: null, // { id, title } if already saved
};

init().catch((error) => {
  setStatus(error instanceof Error ? error.message : String(error), "error");
});

async function init() {
  const stored = await chrome.storage.sync.get(["saversAppUrl"]);
  state.appUrl = normalizeAppUrl(stored.saversAppUrl || DEFAULT_APP_URL);

  bindEvents();

  const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
  if (!tab?.url || !/^https?:/i.test(tab.url)) {
    throw new Error("This tab can't be saved. Open a normal website first.");
  }

  state.tabUrl = tab.url;
  state.tabTitle = tab.title || tab.url;

  els.bookmarkTitle.value = state.tabTitle;

  // Kick off all async init work in parallel
  await Promise.all([
    loadCollections(),
    hydrateMetadata(),
    checkDuplicate(),
  ]);
  await Promise.allSettled([suggestCollection(), suggestTags()]);
  updateUnsyncedBadge();
}

function updateCollectionTriggerLabel() {
  const selected = els.collectionSelect.options[els.collectionSelect.selectedIndex];
  els.collectionTriggerLabel.textContent = selected ? selected.textContent : "Unsorted";
}

function closeCollectionPicker() {
  els.collectionPicker.classList.add("hidden");
  els.collectionTrigger.setAttribute("aria-expanded", "false");
}

function openCollectionPicker() {
  els.collectionPicker.classList.remove("hidden");
  els.collectionTrigger.setAttribute("aria-expanded", "true");
  els.collectionSearch.value = "";
  renderCollectionOptions("");
  els.collectionSearch.focus();
}

function renderCollectionOptions(query) {
  const q = String(query || "").trim().toLowerCase();
  els.collectionOptions.innerHTML = "";
  const filtered = collectionOptionRows.filter((row) => !q || row.searchText.includes(q));

  if (!filtered.length) {
    const empty = document.createElement("div");
    empty.className = "picker-empty";
    empty.textContent = "No collections found";
    els.collectionOptions.appendChild(empty);
    return;
  }

  for (const row of filtered) {
    const btn = document.createElement("button");
    btn.type = "button";
    btn.className = "picker-option";
    if (row.value === els.collectionSelect.value) btn.classList.add("is-active");
    btn.textContent = row.label;
    btn.addEventListener("click", () => {
      els.collectionSelect.value = row.value;
      state.collectionTouched = true;
      updateCollectionTriggerLabel();
      closeCollectionPicker();
    });
    els.collectionOptions.appendChild(btn);
  }
}

function bindEvents() {
  els.collectionSelect.addEventListener("change", () => {
    state.collectionTouched = true;
    updateCollectionTriggerLabel();
  });

  els.collectionTrigger.addEventListener("click", () => {
    if (els.collectionPicker.classList.contains("hidden")) openCollectionPicker();
    else closeCollectionPicker();
  });

  els.collectionSearch.addEventListener("input", () => {
    renderCollectionOptions(els.collectionSearch.value);
  });

  els.suggestCollection.addEventListener("click", () => {
    void suggestCollection(true);
  });

  els.applyAiSuggestion.addEventListener("click", () => {
    void applySuggestion();
  });

  els.dismissAiSuggestion.addEventListener("click", () => {
    clearSuggestion();
    setAiStatus("Suggestion dismissed.");
  });

  els.showCreate.addEventListener("click", () => {
    els.createWrap.classList.remove("hidden");
    els.newCollectionName.value = "";
    els.newCollectionName.focus();
  });

  els.cancelCreate.addEventListener("click", () => {
    els.createWrap.classList.add("hidden");
    els.newCollectionName.value = "";
  });

  els.newCollectionName.addEventListener("keydown", (event) => {
    if (event.key === "Enter") {
      event.preventDefault();
      void handleCreateCollection();
    }
  });

  els.createCollection.addEventListener("click", () => {
    void handleCreateCollection();
  });

  els.refreshMeta.addEventListener("click", () => {
    void (async () => {
      await hydrateMetadata(true);
      await Promise.allSettled([suggestCollection(true), suggestTags()]);
      await checkDuplicate(true);
    })();
  });

  els.openApp.addEventListener("click", () => {
    chrome.tabs.create({ url: state.appUrl });
  });

  els.saveBookmark.addEventListener("click", () => {
    void saveBookmark();
  });

  els.suggestTags.addEventListener("click", () => {
    void suggestTags();
  });

  els.saveAnyway?.addEventListener("click", () => {
    state.duplicate = null;
    els.duplicateWarning.classList.add("hidden");
    void saveBookmark();
  });

  els.openDuplicate?.addEventListener("click", () => {
    if (state.duplicate?.id) {
      chrome.tabs.create({ url: `${state.appUrl}?bookmark=${state.duplicate.id}` });
    }
  });

  document.addEventListener("click", (event) => {
    if (
      !els.collectionPicker.classList.contains("hidden") &&
      !els.collectionPicker.contains(event.target) &&
      event.target !== els.collectionTrigger &&
      !els.collectionTrigger.contains(event.target)
    ) {
      closeCollectionPicker();
    }
  });
}

/* ── Duplicate Check ── */

async function checkDuplicate(force = false) {
  if (!state.tabUrl) return;
  if (state.duplicate && !force) return;

  try {
    const data = await apiFetch(
      `/api/bookmarks/check?url=${encodeURIComponent(state.tabUrl)}`,
      { method: "GET" }
    );
    if (data?.exists) {
      state.duplicate = data.bookmark;
      els.duplicateTitle.textContent = data.bookmark?.title || state.tabUrl;
      els.duplicateWarning.classList.remove("hidden");
    } else {
      state.duplicate = null;
      els.duplicateWarning.classList.add("hidden");
    }
  } catch {
    // Check failed — non-fatal, just don't show duplicate warning
    state.duplicate = null;
    els.duplicateWarning.classList.add("hidden");
  }
}

/* ── Unsynced Badge ── */

async function updateUnsyncedBadge() {
  try {
    const response = await chrome.runtime.sendMessage({ type: "GET_QUEUE_COUNT" });
    const count = response?.count || 0;
    if (count > 0) {
      els.unsyncedCount.textContent = String(count);
      els.unsyncedBadge.classList.remove("hidden");
    } else {
      els.unsyncedBadge.classList.add("hidden");
    }
  } catch {
    els.unsyncedBadge.classList.add("hidden");
  }
}

/* ── Tag Helpers ── */

function parseTags(raw) {
  return String(raw || "")
    .split(",")
    .map((tag) => tag.trim().toLowerCase())
    .filter(Boolean);
}

function appendTag(tag) {
  const existing = parseTags(els.bookmarkTags.value);
  if (existing.some((t) => t === tag.toLowerCase())) return;
  const trimmed = (els.bookmarkTags.value || "").replace(/,\s*$/, "");
  els.bookmarkTags.value = trimmed ? `${trimmed}, ${tag}` : tag;
}

function renderTagProposals() {
  els.tagProposals.innerHTML = "";
  if (!tagProposals.length && !tagSuggestStatus) {
    els.tagProposals.classList.add("hidden");
    return;
  }
  els.tagProposals.classList.remove("hidden");

  for (const tag of tagProposals) {
    const wrap = document.createElement("span");
    wrap.className = "tag-proposal";

    const addBtn = document.createElement("button");
    addBtn.type = "button";
    addBtn.className = "tag-proposal-add";
    addBtn.textContent = `+ ${tag}`;
    addBtn.title = `Add "${tag}"`;
    addBtn.addEventListener("click", () => {
      appendTag(tag);
      tagProposals = tagProposals.filter((t) => t !== tag);
      renderTagProposals();
    });
    wrap.appendChild(addBtn);

    const skipBtn = document.createElement("button");
    skipBtn.type = "button";
    skipBtn.className = "tag-proposal-skip";
    skipBtn.textContent = "×";
    skipBtn.setAttribute("aria-label", `Skip ${tag}`);
    skipBtn.addEventListener("click", () => {
      tagProposals = tagProposals.filter((t) => t !== tag);
      renderTagProposals();
    });
    wrap.appendChild(skipBtn);

    els.tagProposals.appendChild(wrap);
  }

  if (tagSuggestStatus) {
    const status = document.createElement("span");
    status.className = "tag-proposals-status";
    status.textContent = tagSuggestStatus;
    els.tagProposals.appendChild(status);
  }
}

async function suggestTags() {
  if (!state.tabUrl) {
    tagProposals = [];
    tagSuggestStatus = "No URL detected.";
    renderTagProposals();
    return;
  }

  els.suggestTags.disabled = true;
  const previousLabel = els.suggestTags.textContent;
  els.suggestTags.textContent = "Suggesting…";
  tagSuggestStatus = "Reading the page…";
  renderTagProposals();

  try {
    const data = await apiFetch("/api/suggest-tags", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        url: state.tabUrl,
        title: els.bookmarkTitle.value.trim() || state.tabTitle || null,
        description: els.bookmarkDescription.value.trim() || null,
        existing_tags: parseTags(els.bookmarkTags.value),
      }),
    });

    const existing = new Set(parseTags(els.bookmarkTags.value));
    tagProposals = (Array.isArray(data.tags) ? data.tags : []).filter(
      (t) => !existing.has(String(t).toLowerCase())
    );
    tagSuggestStatus = tagProposals.length ? "Tap a tag to add it." : "No new tags to suggest.";
    renderTagProposals();
  } catch (error) {
    tagProposals = [];
    tagSuggestStatus = "Suggestions need a Savers token or sign-in.";
    renderTagProposals();
  } finally {
    els.suggestTags.disabled = false;
    els.suggestTags.textContent = previousLabel;
  }
}

/* ── Collections ── */

async function loadCollections() {
  const data = await apiFetch("/api/collections", { method: "GET" });
  state.flatCollections = Array.isArray(data.flat) ? data.flat : [];

  const paths = buildPaths(state.flatCollections);
  const sorted = [...state.flatCollections].sort((a, b) =>
    (paths.get(a.id) || "").localeCompare(paths.get(b.id) || "")
  );

  els.collectionSelect.innerHTML = "";

  const unsorted = document.createElement("option");
  unsorted.value = "";
  unsorted.textContent = "Unsorted";
  els.collectionSelect.appendChild(unsorted);
  collectionOptionRows = [{ value: "", label: "Unsorted", searchText: "unsorted" }];

  for (const collection of sorted) {
    const option = document.createElement("option");
    option.value = collection.id;
    option.textContent = paths.get(collection.id) || collection.name;
    els.collectionSelect.appendChild(option);
    collectionOptionRows.push({
      value: collection.id,
      label: paths.get(collection.id) || collection.name,
      searchText: `${paths.get(collection.id) || collection.name} ${collection.name}`.toLowerCase(),
    });
  }
  updateCollectionTriggerLabel();
}

/* ── Metadata ── */

async function hydrateMetadata(force = false) {
  if (!state.tabUrl) return;
  if (state.metadata && !force) return;

  try {
    const metadata = await apiFetch(`/api/metadata?url=${encodeURIComponent(state.tabUrl)}`, {
      method: "GET",
    });
    state.metadata = metadata;
    if (metadata.title) {
      els.bookmarkTitle.value = metadata.title;
    }
    if (metadata.description) {
      els.bookmarkDescription.value = metadata.description;
    }
  } catch (error) {
    setStatus(
      error instanceof Error ? `Metadata unavailable: ${error.message}` : "Metadata unavailable.",
      "error"
    );
  }
}

/* ── AI Collection Suggestion ── */

async function suggestCollection(force = false) {
  if (!state.tabUrl) {
    clearSuggestion();
    return;
  }

  if (state.aiSuggestion && !force) return;

  els.suggestCollection.disabled = true;
  setAiStatus("Suggesting a collection…", "brat");

  try {
    const { collections } = await apiFetch("/api/collections", { method: "GET" });
    const data = await apiFetch("/api/categorize", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        url: state.tabUrl,
        title: els.bookmarkTitle.value.trim() || state.tabTitle,
        description: els.bookmarkDescription.value.trim() || null,
        collections,
      }),
    });

    state.aiSuggestion = data?.suggestion || null;

    if (!state.aiSuggestion) {
      clearSuggestion();
      setAiStatus("No clear suggestion.");
      return;
    }

    renderSuggestion();
    if (
      !state.collectionTouched &&
      state.aiSuggestion.collection_id &&
      state.aiSuggestion.confidence !== "low"
    ) {
      els.collectionSelect.value = state.aiSuggestion.collection_id;
      updateCollectionTriggerLabel();
    }
    setAiStatus("");
  } catch (error) {
    clearSuggestion();
    setAiStatus("Collection suggestions need a Savers token or sign-in.", "error");
  } finally {
    els.suggestCollection.disabled = false;
  }
}

function renderSuggestion() {
  const suggestion = state.aiSuggestion;
  if (!suggestion) {
    clearSuggestion();
    return;
  }

  let copy = "";
  let actionLabel = "Use suggestion";

  if (suggestion.collection_id && suggestion.collection_path) {
    copy = `${capitalize(suggestion.confidence)} confidence: ${suggestion.collection_path}`;
  } else if (suggestion.proposed_collection_name) {
    const parent = suggestion.proposed_parent_collection_path
      ? ` under ${suggestion.proposed_parent_collection_path}`
      : "";
    copy = `${capitalize(suggestion.confidence)} confidence: create ${suggestion.proposed_collection_name}${parent}`;
    actionLabel = "Create + use";
  }

  if (!copy) {
    clearSuggestion();
    return;
  }

  els.aiSuggestionCopy.textContent = copy;
  els.applyAiSuggestion.textContent = actionLabel;
  els.aiSuggestion.classList.remove("hidden");
  els.suggestCollection.classList.add("hidden");
}

function clearSuggestion() {
  state.aiSuggestion = null;
  els.aiSuggestionCopy.textContent = "";
  els.aiSuggestion.classList.add("hidden");
  els.applyAiSuggestion.textContent = "Use suggestion";
  els.suggestCollection.classList.remove("hidden");
}

async function applySuggestion() {
  const suggestion = state.aiSuggestion;
  if (!suggestion) return;

  els.applyAiSuggestion.disabled = true;
  try {
    if (suggestion.collection_id) {
      els.collectionSelect.value = suggestion.collection_id;
      state.collectionTouched = true;
      updateCollectionTriggerLabel();
      setAiStatus(`Using ${suggestion.collection_path || "suggested collection"}.`, "success");
      return;
    }

    if (suggestion.proposed_collection_name) {
      const data = await apiFetch("/api/collections", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          name: suggestion.proposed_collection_name,
          parent_id: suggestion.proposed_parent_collection_id || null,
        }),
      });

      const collection = data.collection;
      await loadCollections();
      els.collectionSelect.value = collection.id;
      state.collectionTouched = true;
      updateCollectionTriggerLabel();
      setAiStatus(`Created "${collection.name}".`, "success");
    }
  } catch (error) {
    setAiStatus(
      error instanceof Error ? error.message : "Failed to apply suggestion.",
      "error"
    );
  } finally {
    els.applyAiSuggestion.disabled = false;
  }
}

async function handleCreateCollection() {
  const name = els.newCollectionName.value.trim();
  if (!name) {
    setStatus("Enter a collection name first.", "error");
    return;
  }

  els.createCollection.disabled = true;
  try {
    const data = await apiFetch("/api/collections", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ name, parent_id: null }),
    });

    const collection = data.collection;
    await loadCollections();
    els.collectionSelect.value = collection.id;
    updateCollectionTriggerLabel();
    els.newCollectionName.value = "";
    els.createWrap.classList.add("hidden");
    setStatus(`Created "${collection.name}".`, "success");
  } finally {
    els.createCollection.disabled = false;
  }
}

/* ── Save ── */

async function saveBookmark() {
  if (!state.tabUrl) {
    setStatus("No page URL found for this tab.", "error");
    return;
  }

  els.saveBookmark.disabled = true;

  if (!state.metadata) {
    await hydrateMetadata(true);
  }

  const payload = {
    url: state.tabUrl,
    title: els.bookmarkTitle.value.trim() || state.tabTitle,
    description: els.bookmarkDescription.value.trim() || null,
    og_image: state.metadata?.og_image || null,
    favicon: state.metadata?.favicon || null,
    tags: parseTags(els.bookmarkTags.value),
    notes: null,
    collection_id: els.collectionSelect.value || null,
    source: "extension",
  };

  // Delegate to the background service worker so the save survives
  // the popup closing immediately. The SW handles the API call and
  // shows badge feedback.
  chrome.runtime.sendMessage({ type: "SAVE_PAYLOAD", payload });
  window.close();
}

/* ── API Helpers ── */

async function apiFetch(path, options) {
  const response = await fetch(`${state.appUrl}${path}`, {
    credentials: "include",
    ...options,
  });
  if (!response.ok) {
    let message = `${response.status} ${response.statusText}`;
    try {
      const body = await response.json();
      if (body?.error) message = body.error;
    } catch {}
    throw new Error(message);
  }
  return response.json();
}

/* ── Utilities ── */

function buildPaths(flat) {
  const byId = new Map(flat.map((item) => [item.id, item]));
  const cache = new Map();

  function resolve(id) {
    if (cache.has(id)) return cache.get(id);
    const current = byId.get(id);
    if (!current) return "";
    const value = current.parent_id ? `${resolve(current.parent_id)} / ${current.name}` : current.name;
    cache.set(id, value);
    return value;
  }

  for (const collection of flat) resolve(collection.id);
  return cache;
}

function normalizeAppUrl(value) {
  const raw = String(value || "").trim().replace(/\/+$/, "");
  return raw || DEFAULT_APP_URL;
}

function capitalize(value) {
  return value ? `${value[0].toUpperCase()}${value.slice(1)}` : "";
}

function setStatus(message, kind = "") {
  els.status.textContent = message || "";
  els.status.className = `status ${kind}`.trim();
}

function setAiStatus(message, kind = "") {
  els.aiStatus.textContent = message || "";
  els.aiStatus.className = `status ai-status ${kind}`.trim();
}
